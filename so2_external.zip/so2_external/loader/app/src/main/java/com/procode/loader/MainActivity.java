package com.procode.loader;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.AssetManager;
import android.graphics.Canvas;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Process;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;
import com.topjohnwu.superuser.Shell;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    public static native boolean Init();
    public static native void Stop();

    public static native void DrawESP(ESP espView, Canvas canvas);
    public static native void OnConfigUpdated(int feature, boolean bool_value, int int_value);
    static {
        System.loadLibrary("loader");
    }
    static String pkg = "com.axlebolt.standoff2";
    public static int getProcessID() {
        int pid = -1;
        if (Shell.rootAccess()) {
            String cmd = "for p in /proc/[0-9]*; do [[ $(<$p/cmdline) = " + pkg + " ]] && echo ${p##*/}; done";
            List<String> outs = new ArrayList<>();
            Shell.su(cmd).to(outs).exec();
            if (outs.size() > 0) {
                pid = Integer.parseInt(outs.get(0));
            }
        } else {
            Shell.Result out = Shell.sh("/system/bin/ps -A | grep \"" + pkg + "\"").exec();
            List<String> output = out.getOut();
            if (output.isEmpty() || output.get(0).contains("bad pid")) {
                out = Shell.sh("/system/bin/ps | grep \"" + pkg + "\"").exec();
                output = out.getOut();
                if (!output.isEmpty() && !output.get(0).contains("bad pid")) {
                    for (int i = 0; i < output.size(); i++) {
                        String[] results = output.get(i).trim().replaceAll("( )+", ",").replaceAll("(\n)+", ",").split(",");
                        if (results[8].equals(pkg)) {
                            pid = Integer.parseInt(results[1]);
                        }
                    }
                }
            } else {
                for (int i = 0; i < output.size(); i++) {
                    String[] results = output.get(i).trim().replaceAll("( )+", ",").replaceAll("(\n)+", ",").split(",");
                    for (int j = 0; j < results.length; j++) {
                        if (results[j].equals(pkg)) {
                            pid = Integer.parseInt(results[j - 7]);
                        }
                    }
                }
            }
        }
        return pid;
    }

    public static void copyFile(InputStream in, OutputStream out) throws IOException {
        byte[] buffer = new byte[1024];
        int read;
        while((read = in.read(buffer)) != -1){
            out.write(buffer, 0, read);
        }
    }
    public static void StartMenu(final Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(context)) {
            context.startActivity(new Intent("android.settings.action.MANAGE_OVERLAY_PERMISSION",
                    Uri.parse("package:" + context.getPackageName())));
            Process.killProcess(Process.myPid());
        } else {
            int pid = getProcessID();
            if (pid > 0) {
                AssetManager assetManager = context.getAssets();
                try {
                    String daemonPath = context.getCacheDir().getAbsolutePath() + File.separator + "daemon";
                    Log.d("procode_loader", daemonPath);
                    InputStream in = assetManager.open("daemon");
                    OutputStream out = new FileOutputStream(new File(daemonPath));
                    copyFile(in, out);

                    in.close();
                    out.close();;

                    new File(daemonPath).setExecutable(true, true);

                    new Thread(() -> {
                        String cmd = daemonPath + " " + getProcessID();
                        Log.d("procode_loader", cmd);
                        if (Shell.rootAccess()) {
                            Shell.su(cmd).submit();
                        } else {
                            Shell.sh(cmd).submit();
                        }
                    }).start();

                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            if (Init()) {
                                Toast.makeText(context, "Initialized successfully", Toast.LENGTH_SHORT).show();
                                context.startService(new Intent(context, Menu.class));
                            } else {
                                Toast.makeText(context, "Failed to initialize", Toast.LENGTH_LONG).show();
                            }
                        }
                    }, 5000);
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            } else {
                Toast.makeText(context, "Game not found!", Toast.LENGTH_LONG).show();
            }
        }
    }
    public static void StartUI(final Context context) {
        Button mStart = ((Activity) context).findViewById(R.id.startbtn);
        mStart.setOnClickListener(v -> {
            StartMenu(context);
        });
        Button mStop = ((Activity) context).findViewById(R.id.stopbtn);
        mStop.setOnClickListener(v -> {
            Stop();
            context.stopService(new Intent(context, Menu.class));
        });
    }
    public void Start(final Context context) {
        final SharedPreferences sharedPreferences = context.getSharedPreferences("loader_auth", 0);
        String string = sharedPreferences.getString("loader_key", null);

        //Create LinearLayout
        LinearLayout linearLayout = new LinearLayout(context);
        linearLayout.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
        linearLayout.setOrientation(LinearLayout.VERTICAL);

        //Create username edittext field
        EditText editTextUser = new EditText(context);
        if (string != null && !string.isEmpty()) {
            editTextUser.setText(string);
        }
        editTextUser.setHint("Key...");

        //Create button
        Button button = new Button(context);
        button.setText("Login");

        //Create button
        Button button2 = new Button(context);
        button2.setText("Cancel");

        linearLayout.addView(editTextUser);
        linearLayout.addView(button);
        linearLayout.addView(button2);

        //Create alertdialog
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("Login");
        builder.setCancelable(false);
        builder.setView(linearLayout);
        AlertDialog show = builder.show();

        final EditText editText3 = editTextUser;
        final AlertDialog alertDialog = show;

        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                String user = editText3.getText().toString().trim();
                SharedPreferences.Editor edit = sharedPreferences.edit();

                edit.putString("loader_key", user);
                edit.apply();

                //Check if user and pass match in native lib
                if (user.contains("hui")) {
                    alertDialog.dismiss();
                    setContentView(R.layout.activity_main);
                    StartUI(context);
                } else {
                    Toast.makeText(context, "Username or password is incorrect", Toast.LENGTH_LONG).show();
                }
            }
        });
        button2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                android.os.Process.killProcess(android.os.Process.myPid());
            }
        });
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Start(this);
    }
}