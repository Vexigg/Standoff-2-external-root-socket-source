#include <jni.h>
#include "Includes.h"
#include "client.h"
#include "esp.hpp"
#include "config.hpp"

SocketClient client;
ESP espOverlay;

#define maxplayerCount 30
enum Mode {
    InitMode = 1,
    ESPMode = 2,
    HackMode = 3,
    StopMode = 4,
};

struct Request {
    int Mode;
    int ScreenWidth;
    int ScreenHeight;
};

struct PlayerData {
    std::string PlayerName;
    bool IsTeammate;
    float Health;
    float Distance;
    float BottomX;
    float BottomY;
    float DownX;
    float DownY;
};

struct Response {
    bool Success;
    int DaemonPID;
    int PlayerCount;
    PlayerData Players[maxplayerCount];
};

bool isConnected(){
    return client.connected;
}

bool stopServer(){
    Request request{StopMode, 0, 0};
    int code = client.sendX((void*) &request, sizeof(request));
    if(code > 0){
        Response response{};
        size_t length = client.receive((void*) &response);
        if(length > 0){
            return response.Success;
        }
    }
    return false;
}

void stopClient(){
    if(client.created && isConnected()){
        stopServer();
        client.Close();
    }
}

bool initServer(){
    Request request{InitMode, 0, 0};
    int code = client.sendX((void*) &request, sizeof(request));
    if(code > 0){
        Response response{};
        size_t length = client.receive((void*) &response);
        if(length > 0){
            if (response.Success) {
                LOGI("Daemon initialized!");
                LOGI("Daemon pid: %d", response.DaemonPID);
            }
            return response.Success;
        }
    }
    return false;
}
Response getData(int screenWidth, int screenHeight){
    Request request{ESPMode, screenWidth, screenHeight};
    int code = client.sendX((void*) &request, sizeof(request));
    if(code > 0){
        Response response{};
        size_t length = client.receive((void*) &response);
        if(length > 0){
            return response;
        }
    }
    Response response{false, 0};
    return response;
}
int startClient(){
    client = SocketClient();
    if(!client.Create()){
        LOGE("CE:1");
        return -1;
    }
    if(!client.Connect()){
        LOGE("CE:2");
        return -1;
    }
    if(!initServer()){
        LOGE("CE:3");
        return -1;
    }
    return 0;
}

JNIEXPORT jint JNICALL
JNI_OnLoad(JavaVM *vm, void *reserved) {
    JNIEnv *globalEnv;
    vm->GetEnv((void **) &globalEnv, JNI_VERSION_1_6);

    return JNI_VERSION_1_6;
}

JNIEXPORT void JNICALL
JNI_OnUnload(JavaVM *vm, void *reserved) {}

extern "C"
JNIEXPORT jboolean JNICALL
Java_com_procode_loader_MainActivity_Init(JNIEnv *env, jclass clazz) {
    return startClient() == 0;
}
extern "C"
JNIEXPORT void JNICALL
Java_com_procode_loader_MainActivity_Stop(JNIEnv *env, jclass clazz) {
    stopClient();
}

extern "C"
JNIEXPORT void JNICALL
Java_com_procode_loader_MainActivity_OnConfigUpdated(JNIEnv *env, jclass clazz, jint feature,
                                                     jboolean bool_value, jint int_value) {
    LOGW("Value %d changed: %i / %d", feature, bool_value, int_value);
    switch (feature) {
        case 0:
            isEnableESP = bool_value;
            break;
        case 1:
            isEnableESPLine = bool_value;
            break;
        case 2:
            isEnableESPBox = bool_value;
            break;
        case 3:
            isEnableESPDistance = bool_value;
            break;
        default: {

        }
    }
}

void DrawESP(ESP esp, int screenWidth, int screenHeight) {
    if(isEnableESP){
        esp.DrawCrosshair(Color(0, 0, 0, 255), Vector2(screenWidth / 2, screenHeight / 2), 42);

        Vector2 screen(screenWidth, screenHeight);
        float mScale = screenHeight / (float) 1080;

        Response response = getData(screenWidth, screenHeight);
        if(response.Success) {
            int count = response.PlayerCount;
        }
    }
}

extern "C"
JNIEXPORT void JNICALL
Java_com_procode_loader_MainActivity_DrawESP(JNIEnv *env, jclass clazz, jobject espView,
                                             jobject canvas) {
    espOverlay = ESP(env, espView, canvas);
    if (espOverlay.isValid()){
        DrawESP(espOverlay, espOverlay.getWidth(), espOverlay.getHeight());
    }
}