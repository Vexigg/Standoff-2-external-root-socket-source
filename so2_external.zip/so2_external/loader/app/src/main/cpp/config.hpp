//
// Created by 1337 on 03.11.2023.
//

#ifndef PR0C0DE_CONFIG_HPP
#define PR0C0DE_CONFIG_HPP

bool isEnableESP = false;
bool isEnableESPBox = false;
bool isEnableESPLine = false;
bool isEnableESPDistance = false;

#endif //PR0C0DE_CONFIG_HPP
