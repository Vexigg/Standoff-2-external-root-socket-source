
#include <cstdio>
#include <cstdlib>
#include <cstddef>
#include <dirent.h>
#include <unistd.h>
#include <cmath>
#include <ctime>
#include <string>
#include <vector>
#include <list>
#include <stack>
#include <iostream>
#include <iomanip>
#include <fstream>
#include "socket/server.h"
#include <android/log.h>

using namespace std;

//Log
#define TAG "procode_daemon"
#define LOGI(...) ((void)__android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__))
#define LOGW(...) ((void)__android_log_print(ANDROID_LOG_WARN, TAG, __VA_ARGS__))
#define LOGD(...) ((void)__android_log_print(ANDROID_LOG_DEBUG, TAG, __VA_ARGS__))
#define LOGE(...) ((void)__android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__))

//socket & structs
SocketServer server;

#define maxplayerCount 30
enum Mode {
    InitMode = 1,
    ESPMode = 2,
    HackMode = 3,
    StopMode = 4,
};

struct Request {
    int Mode;
    int ScreenWidth;
    int ScreenHeight;
};

struct PlayerData {
    std::string PlayerName;
    bool IsTeammate;
    float Health;
    float Distance;
	float BottomX;
	float BottomY;
	float DownX;
	float DownY;
};

struct Response {
    bool Success;
	int DaemonPID;
    int PlayerCount;
    PlayerData Players[maxplayerCount];
};

// memory & libraries
pid_t target_pid = -1;
uint64_t libil2cpp = 0;
uint64_t libunity = 0;

#define getRealOffset(x, y) (x + y)

uint64_t get_module_base(const char *module_name) {
    FILE *fp;
    uint64_t addr = 0;
    char filename[32], buffer[1024];
    snprintf(filename, sizeof(filename), "/proc/%d/maps", target_pid);
    fp = fopen(filename, "rt");
    if (fp != nullptr) {
        while (fgets(buffer, sizeof(buffer), fp)) {
            if (strstr(buffer, module_name)) {
                addr = (uintptr_t)strtoul(buffer, nullptr, 16);
                break;
            }
        }
        fclose(fp);
    }
    return addr;
}


int process_vm_readv_syscall = 270; //x64
int process_vm_writev_syscall = 271; //x64
ssize_t process_v(pid_t __pid, const struct iovec* __local_iov, unsigned long __local_iov_count,
	const struct iovec* __remote_iov, unsigned long __remote_iov_count, unsigned long __flags, bool iswrite) {
	return syscall((iswrite ? process_vm_writev_syscall : process_vm_readv_syscall), __pid, __local_iov, __local_iov_count, __remote_iov, __remote_iov_count, __flags);
}

bool pvm(void* address, void* buffer, size_t size, bool iswrite) {
	struct iovec local[1];
	struct iovec remote[1];

	local[0].iov_base = buffer;
	local[0].iov_len = size;
	remote[0].iov_base = address;
	remote[0].iov_len = size;

	if (target_pid < 0) {
		return false;
	}

	ssize_t bytes = process_v(target_pid, local, 1, remote, 1, 0, iswrite);
	return bytes == size;
}

bool vm_readv(void* address, void* buffer, size_t size) {
	return pvm(address, buffer, size, false);
}

bool vm_writev(void* address, void* buffer, size_t size) {
	return pvm(address, buffer, size, true);
}

//memory rw
template <typename T>
T Read(uint64_t address) {
    T data;
    vm_readv(reinterpret_cast<void*>(address), reinterpret_cast<void*>(&data), sizeof(T));
    return data;
}

template <typename T>
void Write(uint64_t address, T data) {
    vm_writev(reinterpret_cast<void*>(address), reinterpret_cast<void*>(&data), sizeof(T));
}

//esp 
int screen_width = 0;
int screen_height = 0;


void createDataList(Response& response) {
	response.PlayerCount = 0;

	uintptr_t photonNetwork = Read<uintptr_t>(libil2cpp + 0x44332E8);
	uintptr_t static_fields = Read<uintptr_t>(photonNetwork + 0xB8); 
	uintptr_t networkingPeer = Read<uintptr_t>(static_fields + 0x18);
	int maxviewids = Read<int>(static_fields + 0x20);
	
	LOGW("got network %llx", photonNetwork);
	LOGW("got static_fields %llx", static_fields);
	LOGW("got networkingPeer %llx", networkingPeer);
	LOGW("got networkingPeer %d", maxviewids);
}
//entry
int main(int argc, char *argv[]) {
	target_pid = atoi(argv[1]);
	if (target_pid == -1) {
		LOGE("Game not found");
		return -1;
	}

	LOGW("Game PID: %d", target_pid);

	libil2cpp = get_module_base("libil2cpp.so");
	libunity = get_module_base("libunity.so");

	if (libil2cpp == 0) {
		LOGE("Can't find libil2cpp.so base address");
		return -1;
	}
	if (libunity == 0) {
		LOGE("Can't find libunity.so base address");
		return -1;
	}

	LOGI("libil2cpp.so: %p", (void *) libil2cpp);
	LOGI("libunity.so: %p", (void *) libunity);

	if (!server.Create()) {
		LOGE("SE:1");
		return -1;
	}

	if (!server.Bind()) {
		LOGE("SE:2");
		return -1;
	}

	if (!server.Listen()) {
		LOGE("SE:3");
		return -1;
	}
	
	if(argc < 2){
		LOGE("SE:4");
		return -1;
	}
	LOGE("Initialized!");
    uint32_t data;
    vm_readv(reinterpret_cast<void*>(libil2cpp), reinterpret_cast<void*>(&data), sizeof(uint32_t));
	LOGW("%p", (void *) data);
    uint32_t data2;
    vm_readv(reinterpret_cast<void*>(libil2cpp + 0xBF4CC4), reinterpret_cast<void*>(&data2), sizeof(uint32_t));
	LOGW("%p", (void *) data2);
	if (server.Accept()) {
		Request request{};
		while (server.receive((void*)& request) > 0) {
			Response response{};

			if (request.Mode == InitMode) {
				LOGE("init!");
				response.Success = true;
				response.DaemonPID = getpid();
			}
			else if (request.Mode == HackMode) {
				LOGE("hack!");
				response.Success = true;
			}
			else if (request.Mode == StopMode) {
				LOGE("bye!");
				response.Success = true;
				server.sendX((void*)& response, sizeof(response));
				break;
			} else if (request.Mode == ESPMode) {
				screen_width = request.ScreenWidth;
				screen_height = request.ScreenHeight;
				createDataList(response);
				response.Success = true;
			}

			server.sendX((void*)& response, sizeof(response));
		}
	}
	
	return 0;
}






