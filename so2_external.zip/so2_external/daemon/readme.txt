Execute this in cmd to compile
E:\AndroidSDK\ndk\25.2.9519653\ndk-build NDK_PROJECT_PATH=E:\so2_external\daemon APP_BUILD_SCRIPT=E:\so2_external\daemon\Android.mk

NDK must be in same drive as daemon project
After compilation, daemon will be located in libs folder.
Currently, only x64 (arm64-v8a) is supported. Implement x32 yourself

After you will compile daemon, put it in assets folder of loader.